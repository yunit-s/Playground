package com.yunit.stt_performance_test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SttPerformanceTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
